NEOSANIYE — GOOGLE FLOW DEVİR PAKETİ
konu: The Man Who Jumped Into the Rain
video süresi: 79.6 s · 19 sahne

ADIMLAR
1. ALL-PROMPTS.txt içindeki blokları görsel modeline ver (her blok bir kare).
   Sıra korunmalı: birinci blok = 01-cold_open, ikinci = 02-fact, …
2. Dönen görselleri şu adlarla kaydet: 01-cold_open.png, 02-fact.png, 04-fact.png …
3. Her görseli Google Flow'a ver. Hareket talimatı olarak O BEAT'İN
   kendi dosyasını kullan: 01-cold_open-MOTION.txt gibi.
   Neden beat başına ayrı: her beat farklı uzunlukta ve hareket metni
   "kurulum %70 / tutuş %30" oranını o süreye göre yazıyor. Tek bir
   10 saniyelik metin kullanıp 4 saniyeye kırpmak ya kurulumu ya da
   oturmuş kareyi öldürüyor. UNIVERSAL-VIDEO-PROMPT.txt 10 saniyelik
   referans sürüm; tek başına klip üretmek istersen o.
4. Flow'dan dönen klipleri AYNI ADLA public/clips/ altına .mp4 olarak koy.
5. npm run beats && npm run render

DİKKAT — ÖLÇÜLDÜ
Flow, "görseli birebir koru" talimatını tam tutmuyor. Bir denemede gravür
harita renkli bir haritayla değişti, tarife içeriği yeniden yazıldı ve
orijinalde olmayan sayfa kıvrımı eklendi. Bu estetikte genelde sorun değil,
AMA çıktıdaki TARİH ve SAYILARI gözle kontrol et; anlatımla çelişen bir
tarih yanlış bilgi demektir.

FLOW'A GİDEN BEAT'LER (17)
  01  0.0s +4.1s  cold_open   "On the night of 24 November 1971,"
  02  4.1s +3.6s  fact        "a man in a dark suit"
  04  12.4s +3.6s  fact        "He handed the attendant a note"
  05  16.0s +5.3s  fact        "that said there was a bomb in his briefcase."
  06  21.3s +5.9s  magnitude   "He asked for two hundred thousand dollars and four parachutes."
  07  27.2s +4.7s  fact        "In Seattle the passengers walked off the plane"
  08  31.9s +3.6s  fact        "and the money came aboard."
  09  35.5s +3.6s  fact        "The aircraft took off again"
  10  39.1s +3.6s  fact        "into rain and low cloud."
  11  42.7s +5.3s  fact        "Somewhere over southern Washington he opened the rear stair"
  12  48.0s +3.6s  fact        "and jumped with a parachute."
  13  51.6s +3.6s  fact        "The FBI searched the woods"
  14  55.2s +3.6s  absence     "for eighteen days and found nothing."
  15  58.8s +5.3s  time        "Nine years later a boy digging on a riverbank"
  16  64.1s +3.6s  fact        "found three bundles of the banknotes."
  17  67.7s +3.6s  fact        "The rest of the money"
  19  74.9s +4.7s  cliffhanger "Nobody ever found the man or the parachute."

KODLA ÇİZİLEN BEAT'LER (2) — Flow'a GİTMEZ
Bu sahnelerde görsel modeli doğru olamıyor: rota oku, sayılabilir ızgara,
grafik, zaman çizelgesi. Remotion çiziyor.
  03  7.7s +4.7s  map_route         "bought a one-way ticket from Portland to Seattle."
  18  71.3s +3.6s  stick_beat        "has never appeared in a bank."
