NEOSANIYE — GÖRSEL ÜRETİM DEVİR PAKETİ
konu: The Man Who Jumped Into the Rain
video süresi: 79.6 s · 19 sahne

═══ B YOLU — PARÇA PARÇA (VARSAYILAN, BUNU KULLAN) ═══

Beat başına 1 PLAKA (boş kağıt zemin) + 4 kadar PARÇA
(düz magenta zeminde tek nesne). Remotion parçaları tek tek, arkadan öne,
anlatı sırasıyla diziyor — yani kolajın kendi kendini kurması KODDA oluyor.
Flow'a hiç gerek yok.

1. ALL-PROMPTS.txt içindeki 69 bloğu görsel modeline ver.
   Her blok bir görsel. Sıra korunmalı.
2. Dönen görselleri ASSET-LIST.txt'deki adlarla collage-raw/ altına kaydet.
   N'inci blok = listenin N'inci satırı. Sıra kayarsa montaj sessizce bozulur.
3. npm run collage
   Bu adım parçaların magenta zeminini silip alfa PNG üretiyor (cutout.py,
   chroma modu), plakayı olduğu gibi alıyor ve storyboard'a bağlıyor.
   Eksik parça sorun değil: o sahne mevcut şablonuyla kodla çizilmeye devam eder.
4. npm run sheet   (tek kareye bak, 93 dakikalık render'a girmeden)
5. npm run render

PARÇA PROMT'UNDA DEĞİŞTİRME: "fill the entire background with pure saturated
magenta" cümlesi süs değil, alfa çıkarımının TEK dayanağı. Zemin magenta
değilse cutout adımı boş maske üretir ve adım hata verir.

═══ A YOLU — TEK KARE + GOOGLE FLOW (YEDEK) ═══

Bir beat için parça üretmek zahmetliyse: NN-kind-FALLBACK-single-frame.txt
tek bitmiş kareyi ister; NN-kind-MOTION.txt o beat'in SÜRESİNE göre yazılmış
Flow hareket metnidir. Klipleri AYNI ADLA public/clips/ altına .mp4 koy ve
npm run clips. O sahne build-on yapmaz, yalnızca film katmanı ve sürüklenme alır.

DİKKAT — ÖLÇÜLDÜ: Flow "görseli birebir koru" talimatını tutmuyor. Bir
denemede gravür harita renkli bir haritayla değişti, tarife içeriği yeniden
yazıldı ve orijinalde olmayan sayfa kıvrımı eklendi. Çıktıdaki TARİH ve
SAYILARI gözle kontrol et; anlatımla çelişen bir tarih yanlış bilgi demektir.
B yolunda bu risk yok, çünkü metni Remotion çiziyor.

GÖRSEL ÜRETİLECEK BEAT'LER (17)
  01  0.0s +4.1s  cold_open   4 parça  "On the night of 24 November 1971,"
  02  4.1s +3.6s  fact        3 parça  "a man in a dark suit"
  04  12.4s +3.6s  fact        3 parça  "He handed the attendant a note"
  05  16.0s +5.3s  fact        3 parça  "that said there was a bomb in his briefcase."
  06  21.3s +5.9s  magnitude   3 parça  "He asked for two hundred thousand dollars and four parachutes."
  07  27.2s +4.7s  fact        3 parça  "In Seattle the passengers walked off the plane"
  08  31.9s +3.6s  fact        3 parça  "and the money came aboard."
  09  35.5s +3.6s  fact        3 parça  "The aircraft took off again"
  10  39.1s +3.6s  fact        3 parça  "into rain and low cloud."
  11  42.7s +5.3s  fact        3 parça  "Somewhere over southern Washington he opened the rear stair"
  12  48.0s +3.6s  fact        3 parça  "and jumped with a parachute."
  13  51.6s +3.6s  fact        3 parça  "The FBI searched the woods"
  14  55.2s +3.6s  absence     3 parça  "for eighteen days and found nothing."
  15  58.8s +5.3s  time        3 parça  "Nine years later a boy digging on a riverbank"
  16  64.1s +3.6s  fact        3 parça  "found three bundles of the banknotes."
  17  67.7s +3.6s  fact        3 parça  "The rest of the money"
  19  74.9s +4.7s  cliffhanger 3 parça  "Nobody ever found the man or the parachute."

KODLA ÇİZİLEN BEAT'LER (2) — görsel üretilmez
Bu sahnelerde görsel modeli doğru olamıyor: rota oku, sayılabilir ızgara,
grafik, zaman çizelgesi. Remotion çiziyor.
  03  7.7s +4.7s  map_route         "bought a one-way ticket from Portland to Seattle."
  18  71.3s +3.6s  stick_beat        "has never appeared in a bank."
